#include "storage.h"

extern ORDER compare (Job j1,Job j2);
